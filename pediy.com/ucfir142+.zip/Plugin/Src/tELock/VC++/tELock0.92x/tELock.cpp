// tELock.cpp : Plugin for ImpREC to find tELock0.92x real API in its wrapped code
////////////////////////////////////////////////////////////////////////////////////////////
//
// Very quick and simple example to get all values in "push [API]; ... garbage ... ;ret"
// Note that this example is not a tracer but just an opcode checker.
//
////////////////////////////////////////////////////////////////////////////////////////////

#include <windows.h>


#define DLLEXPORT extern "C" __declspec( dllexport )

// Exported function to use (prototypes)
////////////////////////////////////////////////////////////////////////////////////////////
DLLEXPORT DWORD Trace(DWORD param);

// Global variables
////////////////////////////////////////////////////////////////////////////////////////////
char	g_temp[_MAX_PATH];		// Windows Temp directory
char	g_ftmp[_MAX_PATH];		// Input File
char	g_ftmp2[_MAX_PATH];		// Output File
DWORD	g_time_out;				// TimeOut
DWORD	g_pointer;				// Pointer to trace (in VA)

// Initialize all you need
BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
	// Get the Temp dir
	GetTempPath(_MAX_PATH, g_temp);

    return TRUE;
}

// Exported function to use
////////////////////////////////////////////////////////////////////////////////////////////
//
// Parameters:
// -----------
// <param> : It will contain the name of the input file
//
// Returned value:
// ---------------
// Use a value greater or equal to 200. It will be shown by ImpREC if no output were created
//
DLLEXPORT DWORD Trace(DWORD param)
{
	// Prepare input/output filenames
	DWORD i;
	strcpy(g_ftmp, g_temp);
	strcat(g_ftmp, "\\");
	i = strlen(g_ftmp);
	*((DWORD*)(g_ftmp+i)) = (DWORD)param;
	g_ftmp[i+4] = '\0';
	strcpy(g_ftmp2, g_ftmp);
	strcat(g_ftmp, ".tmp");
	strcat(g_ftmp2, "_.tmp");

	// Write what is the victim doing with GetProcAddress...
	HANDLE hFile = CreateFile(g_ftmp, GENERIC_READ, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
	if (hFile == INVALID_HANDLE_VALUE)
	{
		// Cannot open/find the input file
		return (201);
	}

	DWORD BytesRead;
	// Read the timeout value
	if (!ReadFile(hFile, &g_time_out, 4, &BytesRead, 0) || BytesRead != 4)
	{
		// Cannot read the timeout
		CloseHandle(hFile);
		return (203);
	}
	// Read the VA of the pointer to trace
	if (!ReadFile(hFile, &g_pointer, 4, &BytesRead, 0) || BytesRead != 4)
	{
		// Cannot read the pointer to trace in
		CloseHandle(hFile);
		return (203);
	}
	CloseHandle(hFile);

	// Check if we read a valid pointer
	if (IsBadReadPtr((VOID*)g_pointer, 4))
	{
		// Bad pointer!
		return (205);
	}

	BYTE *to_trace = (BYTE*)g_pointer;
	// We must have a "push [XXXXXXX]"
	if (to_trace[0] == 0xFF && to_trace[1] == 0x35)
	{
		// Get the pointer in the "push [XXXXXXX]"
		DWORD address = *((DWORD*)(to_trace+2));

		// Check if this pointer is valid
		if (IsBadReadPtr((VOID*)address, 4))
		{
			// Bad pointer!
			return (205);
		}

		// Get the value in XXXXXX
		DWORD val = *((DWORD*)address);

		// Write this value to the output file
		HANDLE hFile = CreateFile(g_ftmp2, GENERIC_WRITE, 0, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
		if (hFile == INVALID_HANDLE_VALUE)
		{
			// Open for writing error
			return (207);
		}
		DWORD BytesWritten;
		if (!WriteFile(hFile, &val, 4, &BytesWritten, 0))
		{
			// Write error?
			CloseHandle(hFile);
			return (209);
		}
		CloseHandle(hFile);
	}

	// OK
	return (200);
}
