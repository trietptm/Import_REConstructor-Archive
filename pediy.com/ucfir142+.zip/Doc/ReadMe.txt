=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=
~               Import REConstructor v1.4.2+ by MackT/uCF2000 in 2001-2002            ~
=                                                                                     =
~                        - *Tested on Windows 98SE, ME, 2K, XP* -                     ~
=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=

Disclaimer:
-----------
This program may crash, or in a worse case it may even reboot your computer, so please use
it with caution. (Do not run it 3 hours into an unsaved coding session for example)

I am *NOT* responsible for any damage caused by the use of it.


Purpose:
--------
This tool is designed to rebuild all new imports datas from a corrupted IAT (redirected
pointers or not by a PE-packer for example). It reconstructs a new Image Import Descriptor,
IAT and all ASCII module and function names.
It can now inject into your output executable, a loader which is able to fill the IAT with
real pointers to API or a ripped code from the protector/packer (very useful against
emulated API in a thunk).

Sorry but this tool is not designed for newbies, you should be familiar with unpacking
first (some tuts are easy to find on internet...).


What it needs?
--------------
- A full dump of the target

- A running process of your target (for the tracer engine)

- You have to find OEP manually (or with /tracex command of icedump) for using the Original
  IAT auto finder ('IAT AutoSearch' button)
  Else you need the range which contains the Original IAT

- A brain to code your own tracer if you do not want to wait for update because of my
  lazyness


How it works?
-------------
1  - Select the target in the process list.
     (Its EIP will be automatically put in the OEP editbox)

2  - If you have the OEP:
         - Enter it (IN RVA) in the appropriate editbox and press "IAT AutoSearch" button
	   to get possible rva address and size values which can contain the original IAT
     Else:
         - Enter the rva address and size of IAT

3  - Press "Get Imports" button

4  - Press "Show Invalid" button and analyze quickly all "invalid" addresses.
     Right click on the tree for tracing in them. *ALWAYS* try the Tracer Level 1 first.
     It is the less "dangerous".

5  - Repress on "Show Invalid" button and look at new results.
     If there are still invalid addresses, try the other tracers. Do not trace immediately
     a big block. Test one by one first and if it successes, you can select all invalid
     pointers in the thunk.

6  - Press on "Show Suspect" for checking wrong traced (it is possible because of the
     tracer level1 which is a simple disassembler and only get direct API call). If there
     are, invalidate them and retrace into them with the other tracers. If all fails and
     you know the real API, double click on it and enter it.

7  - Play with "Invalidate function(s)", "Delete thunk(s)", Edit Import (double click on
     a function) and tracers until all is done.

8  - If you do not want to add a new section and know where you can put the new rebuilt
     import (in the last section for example), uncheck "Add new section" and enter the
     wanted RVA. (the easiest way is to add a new section though (by default))

9  - Press "Fix Dump" to fix your DUMPED file. You do not need to make a backup. If your
     filename is "Dump.exe", it will create "Dump_.exe". Moreover the EP of your dump will
     be fixed by the value you have entered if you turned "Fix EP to EIP" on, in options.

10 - Pheeeww, your fixed dump should work...


Options:
--------
- "Import all by ordinal" : It needs less size than the usual import (by name and ordinal)
  but is not portable. Use it ** IF AND ONLY IF ** you want to rebuild the exe ONLY for
  your system and want a smaller file.

- The "Max Recursion" is the number of conditionnal jumps or calls it's allowed to follow
  when the tracer level1 is in action. More this number is big and more you have to wait,
  use it CAREFULLY. (You can stop its progression by pressing "CONTROL+F12")

- The "Buffer Size" is the size of the allocated memory block for tracing for EACH
  recursion. (still for the tracer level1)

- "Fix EP to OEP" : Turn on this option if you want to set the EIP of your dump file to
  the OEP you have given in ImpREC.

- "Time Out" : Time out for stopping tracers level2 and 3 in their progression. The value
  is in 50 milliseconds and in decimal.

- "Enable Debug Privilege (NT/2K/XP)" : Enable this if your target is not listed in the
  process combobox selector. You will need to restart ImpREC to activate it.

- "Fix Damaged PDB (Win9X/ME Only)" : Enable this if the target has hacked its PDB (ugly)
  against process opening. You will need to restart ImpREC to activate it.

- "Use PE Header From Disk" : Use the PE Header of the disk rather than the dump.

- "Renormalize Exports (W9X/ME)" : Use this to get a better portable executable. You must
  run ImpREC at least once before running your target with this option enabled. You will
  need to restart ImpREC to activate it.

- "Exact Call" : Enable this to rebuild imports like Safecast/Safedisc 2 scheme.

- "Create New IAT" : Enable this to create a new IAT. Do not forget to precise all sections
  which contains the code to modify by right clicking on the tree for a "Select Code
  Section(s)"



Commands:
---------
- "IAT AutoSearch"        : Give it an OEP and it will try to find the IAT RVA and its size
                            for you.

- "Get Imports"           : Build the IAT described by a RVA and a size into a tree.

- "Show Invalid"          : Select all pointers in the IAT which are still invalid
                            (redirected)

- "Show Suspect"          : Select all valid functions which need a manual check of your
                            part. It will select all same functions in the same thunk and
                            all thunk which has only one function.

- "Auto Trace"            : An automatic tracer which will use the tracer level1 on all
                            invalid pointers. It will apply the tracer level2 on suspect
                            entries. Do not expect so much on it because it will never be
                            able to replace some manual actions of your part. It is here
                            for showing how to rebuild "Notepad_asp.exe".

- "Clear Imports"         : Clear all current imports

- "Clear Log"             : Clear the log window

- "Load Tree"             : Load a tree. (You still can load old ".rec" files)

- "Save Tree"             : Save your current tree in a file. (text format)

- "Fix Dump"              : Add your current import into a dumped file of your target

- "Get API Calls"         : This feature will get all call[] and jmp[] from the target to
                            your imports. Its first purpose is to find internal calls to
                            the protector which does not belong to the IAT. After getting
                            them, switch them to the loader which will rip the code of the
                            protector to your dump file.

- "Select Code Section(s) : To use for "Get API Calls", "Create New IAT" and "Exact Call".
                            It will precise to them which sections contains code (for
                            redirect all calls to the new IAT or to get all calls).


Notes
-----
- If the Original IAT AutoFinder fails, several method can be tried:
	- Try to play with "Max Recursion" or/and "Buffer Size" in the options.
	- Try to use the tracer in the .rdata or .idata section.
	- If it fails, try each section but it's not a good method if some sections are
	  really big
	- The best method (which the Original IAT AutoFinder tries to do) is to trace at
	  the OEP and look for the first API call, get the address and use the tracer into
	  the WHOLE section which contains this address.

- If the IAT is cutted in different parts, you can put IAT RVA and SIZE manually and
  press "Get Imports" for all of them. Your added imports will be stuck together
  automaticaly.

- I advise you to put the new import datas into the last section if it was packed. Because
  all packers i know (except UPX, ...), put their "garbage" in the last section. Add a new
  section only if you do not care about the size of your rebuilt executable.


Limitations
-----------
- The tree accepts multiple selections. I had to make it manually because the original
  control did not. It is not yet perfect if you play with focus.
  So do not be surprised... And no, i will not fix that.

- The original-IAT auto finder will not work if this one is not contigous (ie: cutted in
  different parts of the exe for each thunks) so you will have to put RVA and SIZE manually.

- The loader can't actually reloc datas

- Tracers are always to be improved but you can code yours!


Personal greetings:
-------------------
Look at the 'About' dialogbox.
